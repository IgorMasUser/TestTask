﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test2;
using Xunit;

namespace Test2
{
    public partial class ComparrerApp : Form
    {
        public ComparrerApp()
        {
            InitializeComponent();
        }

        private void cmdGO_Click(object sender, EventArgs e)
        {
            Data rClient = new Data();

            rClient.endPointFirst = firstURI.Text;

            rClient.endPointSecond = secondURI.Text;

            rClient.JSONFirst = First_JSON_Body.Text;

            rClient.JSONSecond = Second_JSON_Body.Text;

            rClient.Converter(rClient.JSONFirst);

            rClient.Converter(rClient.JSONSecond);

            string compareValue = rClient.CompareValues(rClient.JSONFirst, rClient.JSONSecond);

            string result = rClient.GetDifferences(rClient.JSONFirst, rClient.JSONSecond);

            try
            {
                System.Diagnostics.Debug.Write(result + Environment.NewLine + compareValue);
                Сomparison.Text = Сomparison.Text + result + Environment.NewLine + compareValue;
                Сomparison.SelectionStart = Сomparison.TextLength;
                Сomparison.ScrollToCaret();
            }

            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message, ToString() + Environment.NewLine);
            }

        }

        private void Form1_Load(object sender, EventArgs e)

        {


        }

        private void JSON_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

namespace JSON_Comparrer.Unit_Test
{
    public class DiffUtilsTest
    {
        [Fact]
        public static void IsEqualSize_Checks_If_Base64_Values_Are_Equal_Size()
        {
            string leftBase64 = "VGVzdDEyMw==";
            string rightBase64 = "VGVzdDEyMw==";
            Assert.Equal(true, Data.IsEqualSize(leftBase64, rightBase64));

        }
        [Fact]
        public static void IsEqualSize_Checks_If_Base64_Values_Are_Not_Equal()
        {
            string leftBase64 = "VGVzdDEyMw==";
            string rightBase64 = "eyJpbnB1dCI6InRlc3RWYWx1ZSJ9";
            Assert.NotEqual(true, Data.IsEqualSize(leftBase64, rightBase64));

        }
        [Fact]
        public static void IsEqualSize_Checks_If_Base64_ArraySizes_are_Equal()
        {
            byte[] left = Convert.FromBase64String("VGVzdDEyMw==");
            byte[] right = Convert.FromBase64String("VGVzdDEyMw==");
            Assert.Equal(true, Data.IsEqualLengths(left, right));

        }
        [Fact]
        public static void IsEqualSize_Checks_If_Base64_ArraySizes_are_Not_Equal()
        {
            byte[] left = Convert.FromBase64String("VGVzdDEyMw==");
            byte[] right = Convert.FromBase64String("eyJpbnB1dCI6InRlc3RWYWx1ZSJ9");
            Assert.NotEqual(true, Data.IsEqualLengths(left, right));

        }
    }
}

