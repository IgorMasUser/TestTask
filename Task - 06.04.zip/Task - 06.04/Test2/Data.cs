﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;

namespace Test2
{

    class Data
    {

        public string endPointFirst { get; set; }

        public string JSONFirst { get; set;}

        public string JSONSecond { get; set;}
        
        public string endPointSecond { get; set; }

        public string endPointDiff { get; set; }

        public string result { get; set; }


        public string Converter(string JSON)

        {

            byte[] data = Convert.FromBase64String(JSON);

            string decodedString = Encoding.UTF8.GetString(data);

            return decodedString;

        }

        public static bool IsEqualSize(string JSONFirst, string JSONSecond)
        {
            var left = Convert.FromBase64String(JSONFirst);
            var right = Convert.FromBase64String(JSONSecond);

            return left.Length == right.Length;
        }

        public static bool IsEqualLengths(byte[] left, byte[] right)
        {
            return left.Length == right.Length;
        }


        public string GetDifferences(string JSONFirst, string JSONSecond)
        {
            int Offset = 0;
            int Length = 0;

            

            var left = Convert.FromBase64String(JSONFirst);
            var right = Convert.FromBase64String(JSONSecond);

            if (!IsEqualLengths(left, right) || left.Length == 0)
            {
                return "inputs are of different size";
            }

            else
            {
                var isEqual = true;
                var notEqualIndex = 0;

                for (int i = 0; i < left.Length; i++)
                {
                    var nextIsEqual = left[i] == right[i];

                    if (isEqual && !nextIsEqual)
                    {
                        notEqualIndex = i;
                        isEqual = false;
                    }
                    else if (!isEqual && nextIsEqual)
                    {

                        Offset = notEqualIndex;
                        Length = i - notEqualIndex;

                    }
                }

                result = "Offset diff is " + Offset + "; " + "Length diff is " + Length;

                return result;

            }
      

        }

        public string CompareValues(string JSONFirst, string JSONSecond)

        {
            if (JSONFirst.Equals(JSONSecond))
            {
                return "inputs were equal";

            }

            return "inputs were not equal";

        }

    }

}
